#include <stdio.h>
#include "freertos/FreeRTOS.h" //Para usar delays
#include "freertos/task.h"
#include "driver/gpio.h"    //para configurar gpios


#define led0 2


void app_main(){
    gpio_set_direction(led0, GPIO_MODE_OUTPUT);

    while(1){
        gpio_set_level(led0,1);  // 1 = On, 0 = Off
        vTaskDelay(1000/ portTICK_PERIOD_MS);
        gpio_set_level(led0,0);
        vTaskDelay(1000/ portTICK_PERIOD_MS);
    }
}