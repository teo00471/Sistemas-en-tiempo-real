#ifndef QUEUE_H_
#define QUEUE_H_


#include "freertos/queue.h"


#define LONGITUD_COLA_TEMPERATURA 10
#define LONGITUD_COLA_SEND 10

//VARIABLES UTILIZADAS POR LAS COLAS 
int valVac;
float valIac;
int Potencia;
int limite_threshold;
int red_control;
int green_control;
int blue_control;

//COLAS CREADAS EN EL MAIN.C Y UTILIZADAS EN http_server.c

extern QueueHandle_t cola_voltaje;
extern QueueHandle_t cola_corriente;
extern QueueHandle_t cola_potencia;
extern QueueHandle_t cola_threshold;
extern QueueHandle_t cola_red;
extern QueueHandle_t cola_green;
extern QueueHandle_t cola_blue;

#endif /* QUEUE_H_*/


