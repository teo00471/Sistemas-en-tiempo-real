/**
 * Application entry point.
 */

#include "nvs_flash.h"
#include <stdio.h>
#include "wifi_app.h"
#include "rgb_led.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "driver/adc.h"
#include <string.h>
#include "freertos/queue.h"
#include "math.h"
#include "http_server.h"

#define TIMER_INTERVAL_US 190
#define NUM_SAMPLES 100

// VARIABLES PARA LECTURA DEL ADC
int numbers[NUM_SAMPLES];
int numbersI[NUM_SAMPLES];
int sample_count = 0;
int var_prom = 0;
int contador_prom = 0;
float temperatura = 0;

// COLAS PARA LA MANDAR LOS DATOS Y RECIBIR LOS DATOS DE LA LIBRERIA http_server.c
QueueHandle_t cola_temperatura;
QueueHandle_t cola_threshold_1;
QueueHandle_t cola_threshold_2;
QueueHandle_t cola_threshold_3;
QueueHandle_t cola_threshold_4;
QueueHandle_t cola_threshold_5;
QueueHandle_t cola_threshold_6;
QueueHandle_t cola_red;
QueueHandle_t cola_green;
QueueHandle_t cola_blue;

// INICIALIZACION DEL LED RGB
static void configure_led(void)
{

    gpio_reset_pin(BLINK_GPIO);
    /* Set the GPIO as a push/pull output */
    gpio_set_direction(BLINK_GPIO, GPIO_MODE_OUTPUT);
    rgb_led_pwm_init();
}

int read_adc()
{

    adc1_config_channel_atten(ADC1_CHANNEL_6, ADC_ATTEN_DB_11);

    int valTemperatura = adc1_get_raw(ADC1_CHANNEL_6);
    return valTemperatura;
}

// Funcion para encontrar el numero mayor del arreglo que se le envie
int find_max_number(int numbers[], int count)
{
    int max = numbers[0];
    for (int i = 1; i < count; i++)
    {
        if (numbers[i] > max)
        {
            max = numbers[i];
        }
    }
    return max;
}

// Manejador de interrupción del temporizador
void timer_callback(void *arg)
{
    if (sample_count < NUM_SAMPLES)
    {
        numbers[sample_count] = read_adc();
        sample_count++;
    }

    if (sample_count >= NUM_SAMPLES)
    {
        int max_number = find_max_number(numbers, NUM_SAMPLES);

        var_prom = var_prom + max_number;
        contador_prom++;
        // printf("El número mayor es: %d\n", max_number);
        sample_count = 0;
        memset(numbers, 0, sizeof(numbers));
    }

    if (contador_prom == 100)
    {
        var_prom = var_prom / 100;

        temperatura = escalarTemperatura(var_prom);
        xQueueSend(cola_temperatura, &temperatura, pdMS_TO_TICKS(100));
        printf("La temperatura es: %d\n", temperatura);
        var_prom = 0;
        contador_prom = 0;
    }
}

// Configurar y habilitar el timer con su respectiva interrupcion
void configure_timer()
{
    esp_timer_create_args_t timer_config = {
        .callback = timer_callback,
        .name = "my_timer"};
    esp_timer_handle_t timer;
    esp_timer_create(&timer_config, &timer);
    esp_timer_start_periodic(timer, 230); // Intervalo de 230 microsegundos
}

void control_threshold_1()
{
    while (true)
    {
        int Temperatura;
        int limite_threshold_1;
        int limite_threshold_2;
        int red_control;
        int green_control;
        int blue_control;

        xQueueReceive(cola_temperatura, &Temperatura, pdMS_TO_TICKS(100));
        xQueueReceive(cola_threshold_1, &limite_threshold_1, pdMS_TO_TICKS(100));
         xQueueReceive(cola_threshold_2, &limite_threshold_2, pdMS_TO_TICKS(100));
        xQueueReceive(cola_red, &red_control, pdMS_TO_TICKS(100));
        xQueueReceive(cola_green, &green_control, pdMS_TO_TICKS(100));
        xQueueReceive(cola_blue, &blue_control, pdMS_TO_TICKS(100));
        if (limite_threshold_1  > Temperatura < limite_threshold_2)
        {
            rgb_led_set_color(0, 0, 0);
        }
        else
        {
            rgb_led_set_color(red_control, green_control, blue_control);
        }
        vTaskDelay(100);
    }
}

void control_threshold_2()
{
    while (true)
    {
        int Temperatura;
        int limite_threshold_3;
        int limite_threshold_4;
        int red_control;
        int green_control;
        int blue_control;

        xQueueReceive(cola_temperatura, &Temperatura, pdMS_TO_TICKS(100));
        xQueueReceive(cola_threshold_3, &limite_threshold_3, pdMS_TO_TICKS(100));
         xQueueReceive(cola_threshold_4, &limite_threshold_4, pdMS_TO_TICKS(100));
        xQueueReceive(cola_red, &red_control, pdMS_TO_TICKS(100));
        xQueueReceive(cola_green, &green_control, pdMS_TO_TICKS(100));
        xQueueReceive(cola_blue, &blue_control, pdMS_TO_TICKS(100));
        if (limite_threshold_3  > Temperatura < limite_threshold_4)
        {
            rgb_led_set_color(0, 0, 0);
        }
        else
        {
            rgb_led_set_color(red_control, green_control, blue_control);
        }
        vTaskDelay(100);
    }
}
void control_threshold_3()
{
    while (true)
    {
        int Temperatura;
        int limite_threshold_5;
        int limite_threshold_6;
        int red_control;
        int green_control;
        int blue_control;

        xQueueReceive(cola_temperatura, &Temperatura, pdMS_TO_TICKS(100));
        xQueueReceive(cola_threshold_5, &limite_threshold_5, pdMS_TO_TICKS(100));
         xQueueReceive(cola_threshold_6, &limite_threshold_6, pdMS_TO_TICKS(100));
        xQueueReceive(cola_red, &red_control, pdMS_TO_TICKS(100));
        xQueueReceive(cola_green, &green_control, pdMS_TO_TICKS(100));
        xQueueReceive(cola_blue, &blue_control, pdMS_TO_TICKS(100));
        if (limite_threshold_1  > Temperatura < limite_threshold_2)
        {
            rgb_led_set_color(0, 0, 0);
        }
        else
        {
            rgb_led_set_color(red_control, green_control, blue_control);
        }
        vTaskDelay(100);
    }
}
void app_main(void)
{
    adc1_config_width(ADC_BITWIDTH_12);
    configure_timer();
    configure_led();
    // Initialize NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    // Start Wifi
    wifi_app_start();

    // COLAS QUE ENVIAN DATOS AL HTTP_SERVER.C
    cola_temperatura = xQueueCreate(LONGITUD_COLA_SEND, sizeof(int));

    // COLAS QUE RECIBEN DATOS DE HTTP_SERVER.C
    cola_threshold_1 = xQueueCreate(LONGITUD_COLA_SEND, sizeof(int));
    cola_threshold_2 = xQueueCreate(LONGITUD_COLA_SEND, sizeof(int));
    cola_threshold_3 = xQueueCreate(LONGITUD_COLA_SEND, sizeof(int));
    cola_red = xQueueCreate(LONGITUD_COLA_SEND, sizeof(int));
    cola_green = xQueueCreate(LONGITUD_COLA_SEND, sizeof(int));
    cola_blue = xQueueCreate(LONGITUD_COLA_SEND, sizeof(int));

    // TAREAS PARA EL FUNCIONAMIENTO DE SENSORES Y RGB
    xTaskCreatePinnedToCore(control_threshold_1, "control_threshold_1", 1024 * 2, NULL, configMAX_PRIORITIES - 1, NULL, 1);
    xTaskCreatePinnedToCore(control_threshold_2, "control_threshold_2", 1024 * 2, NULL, configMAX_PRIORITIES - 1, NULL, 1);
    xTaskCreatePinnedToCore(control_threshold_3, "control_threshold_3", 1024 * 2, NULL, configMAX_PRIORITIES - 1, NULL, 1);
}